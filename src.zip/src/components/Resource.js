import React from 'react';

const Resource = ({ resource }) => {
  return <div className="resource">{resource}</div>;
};

export default Resource;
